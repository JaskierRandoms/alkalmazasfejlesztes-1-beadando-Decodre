﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Data;

namespace Telefonkönyv
{
    class Connection
    {
        private static MySqlConnection conn = new MySqlConnection("SERVER=localhost;UID=root;PWD=;DATABASE=phonebook");

        private static void Connect()
        {
            try
            {
                conn.Open();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        public static void ListBoxFill(ListBox lb)
        {
            MySqlDataAdapter da = new MySqlDataAdapter("SELECT id, name FROM contacts", conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            lb.ItemsSource = ds.Tables[0].DefaultView;
            lb.DisplayMemberPath = ds.Tables[0].Columns["name"].ToString();
            lb.SelectedValuePath = ds.Tables[0].Columns["id"].ToString();
        }
        public static void ListBoxFill_extended(ListBox lb)
        {
            MySqlDataAdapter da = new MySqlDataAdapter("SELECT id, CONCAT_WS(' ', name, number, type) as ossz FROM contacts", conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            lb.ItemsSource = ds.Tables[0].DefaultView;
            lb.DisplayMemberPath = ds.Tables[0].Columns["ossz"].ToString();
            lb.SelectedValuePath = ds.Tables[0].Columns[0].ToString();
        }
        public static void AddNew(TextBox name, TextBox number, ComboBox type)
        {
            Connect();
            if (name.Text != "" && number.Text != "")
            {
                string sql;
                MySqlCommand cmd;
                sql = string.Format("INSERT INTO contacts(id, name, number, type) VALUES(NULL, '{0}', '{1}', '{2}')", name.Text, number.Text, type.Text);
                cmd = new MySqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Új elérhetőség hozzáadva!");
            }
            else
            {
                MessageBox.Show("Kérem töltse ki az összes mezőt!");
            }
            conn.Close();
        }

        public static void Torol(int id)
        {
            Connect();
           string sql;
           MySqlCommand cmd;
           sql = string.Format("DELETE FROM contacts WHERE contacts.id = " + id);
           cmd = new MySqlCommand(sql, conn);
           cmd.ExecuteNonQuery();
           MessageBox.Show("Elérhetőség eltávolítva!");
            conn.Close();
        }

        public static void GetValues(int id,ref string[] data)
        {
            data = new string[3];
            Connect();
            MySqlCommand cmd = new MySqlCommand("SELECT name, number, type FROM contacts WHERE id = " + id, conn);
            MySqlDataReader rd = cmd.ExecuteReader();
            if (rd.HasRows)
            {
                rd.Read();
                data[0] = rd.GetString(0);
                data[1] = rd.GetString(1);
                data[2] = rd.GetString(2);
                rd.Close();
            }
            conn.Close();
        }

        public static void UpdateDb(TextBox name, TextBox number, ComboBox type, int id)
        {
            Connect();
            if (name.Text != "" && number.Text != "")
            {
                string sql;
                MySqlCommand cmd;
                sql = string.Format("UPDATE contacts SET name='{0}',number='{1}',type='{2}' WHERE id = {3}", name.Text, number.Text, type.Text, id);
                cmd = new MySqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Elérhetőség módosítva!");
            }
            else
            {
                MessageBox.Show("Kérem töltse ki az összes mezőt!");
            }
            conn.Close();
        }
    }
}
