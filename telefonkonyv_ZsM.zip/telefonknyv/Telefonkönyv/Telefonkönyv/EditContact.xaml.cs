﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Telefonkönyv
{
    /// <summary>
    /// Interaction logic for EditContact.xaml
    /// </summary>
    public partial class EditContact : Window
    {
        string[] data = new string[3];
        int id;
        public EditContact(string[] data, int id)
        {
            InitializeComponent();
            this.data[0] = data[0];
            this.data[1] = data[1];
            this.data[2] = data[2];
            this.id = id;
            SetValues();
        }

        void SetValues()
        {
            nevbox.Text = data[0];
            telefonbox.Text = data[1];
            if (tipusbox.Text != data[2])
                tipusbox.SelectedIndex = 1;
        }

        private void Hozzaad_button_Click(object sender, RoutedEventArgs e)
        {
            Connection.UpdateDb(nevbox,telefonbox,tipusbox, id);
        }
    }
}
