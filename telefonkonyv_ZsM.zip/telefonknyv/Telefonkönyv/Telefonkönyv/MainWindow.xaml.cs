﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Data;

namespace Telefonkönyv
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        bool nezet=false;
        public int id;
        public string[] data;
        public MainWindow()
        {
            InitializeComponent();
            Connection.ListBoxFill(Lista);
        }

        private void View_button_Click(object sender, RoutedEventArgs e)
        {
            if (nezet)
            {
                Connection.ListBoxFill(Lista);
                View_button.Content = "Részletes nézet";
                nezet = false;
                return;
            }
            Connection.ListBoxFill_extended(Lista);
            View_button.Content = "Minimalista nézet";
            nezet = true;
        }

        private void New_button_Click(object sender, RoutedEventArgs e)
        {
            NewContact winform = new NewContact();
            winform.ShowDialog();
            Lista.ItemsSource = null;
            Lista.Items.Clear();
            Connection.ListBoxFill(Lista);
        }

        private void Del_button_Click(object sender, RoutedEventArgs e)
        {
            if (Lista.SelectedItem != null)
            {
                Connection.Torol(int.Parse(Lista.SelectedValue.ToString()));
                Lista.ItemsSource = null;
                Lista.Items.Clear();
                Connection.ListBoxFill(Lista);
            }
            else
                MessageBox.Show("Válaszd ki a törölni kívánt elérhetőséget!");
        }

        private void Szerk_button_Click(object sender, RoutedEventArgs e)
        {
            if (Lista.SelectedItem != null)
            {
                id = int.Parse(Lista.SelectedValue.ToString());
                Connection.GetValues(id, ref data);
                EditContact winform = new EditContact(data, id);
                winform.ShowDialog();
                Lista.ItemsSource = null;
                Lista.Items.Clear();
                Connection.ListBoxFill(Lista);
            }
            else
                MessageBox.Show("Válaszd ki a szerkeszteni kívánt elérhetőséget!");
        }

    }
}
